package finances;

import impl.Product;
import impl.ProductRepositoryImpl;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class StoreTest {

    private Store store;
    private Product product;
    @BeforeEach
    void setUp() {
        store = new Store(new ProductRepositoryImpl());
        product = new Product("Ziemniaki", new Price(3, 60), 100);
    }

    @org.junit.jupiter.api.Test
    void productDeliveryIfExists() {
        //given
        store.productDelivery("Ziemniaki", new Price(3, 60), 100);
        //when
        store.productDelivery("Ziemniaki", new Price(3, 60), 50);
        //then
        String expected = "Ziemniaki, 3,60, 150\n";
        assertEquals(expected, store.toString());

    }

    @org.junit.jupiter.api.Test
    void productDeliveryIfNotExists() {

    }


    @org.junit.jupiter.api.Test
    void productSale() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}