package impl;

import finances.Price;

import java.util.Objects;

public class Product {
    private String name;
    private Price price;
    private int amount;

    public String getName() {
        return name;
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Product(String name, Price price, int amount) {
        this.price = price;
        this.name = name;
        this.amount = amount;
    }

    public String toString() {
        return name + ", " + price + ", " + amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return name.equals(product.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

}
