package finances;


// należy zaimplementowac interfejs Comparable
public class Price implements Comparable{

    private int zlote;
    private int grosze;

    public Price(int zlote, int grosze) {
        if (zlote < 0 || grosze < 0) {
            throw new IllegalArgumentException();
        } else {
            if (grosze > 99) {
                int ile = grosze / 100;
                grosze = grosze - 100 * ile;
                zlote = zlote + 1 * ile;
            }
            this.zlote = zlote;
            this.grosze = grosze;
        }
    }

    public int getZlote() {
        return zlote;
    }

    public int getGrosze() {
        return grosze;
    }

    public Price() {
    }

    @Override
    public String toString() {
        if (grosze > 9) {
            return zlote + "," + grosze;
        } else {
            return zlote + ",0" + grosze;
        }
    }

    public Price add (Price price) {
        int zl = this.zlote + price.zlote;
        int gr = this.grosze + price.grosze;
        if (gr > 99) {
            zl++;
            gr = gr - 100;
        }
        return new Price(zl, gr);
    }

    public Price multiply(int ile) {
        int gr = (grosze + zlote * 100) * ile;
        return new Price(gr / 100, gr % 100);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Price Price = (Price) o;

        if (zlote != Price.zlote) return false;
        return grosze == Price.grosze;
    }

    @Override
    public int hashCode() {
        int result = zlote;
        result = 31 * result + grosze;
        return result;
    }

    public int compareTo(Object o) {
        Price price = (Price) o;
        if(100*price.zlote + price.grosze > 100*zlote+grosze) {
            return -1;
        } else if (100*price.zlote + price.grosze == 100*zlote+grosze) {
            return 0;
        } else {
            return 1;
        }
    }
}
