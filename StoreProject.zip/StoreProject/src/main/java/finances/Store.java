package finances;

import api.ProductRepository;
import impl.Product;

public class Store {
    private ProductRepository repository;

    public Store(ProductRepository repository){
        this.repository = repository;
    }

    public void productDelivery(String name, Price price, int amount){
        if(repository.exists(name)) {
            repository.findByName(name).setAmount(repository.findByName(name).getAmount() + amount);
        } else {
            repository.create(new Product(name, price, amount));
        }
    }

    //wyrzuca wyjatek jesli brak (nie ma produktu, lub za malo)
    public void productSale(String name, int amount) {
        if(repository.findByName(name).getAmount() < amount) {
            throw new IllegalStateException("Not enough amount");
        } else {
            repository.findByName(name).setAmount(repository.findByName(name).getAmount() - amount);
        }
    }
    //zwraca null, jeśli brak
    public Price priceToPay(String name, int amount){return null;}
    //zwraca null, jesli brak
    public Price productPrice(String name){return null;}
    //zwraca 0, jesli brak
    public int productAmount(String name){return 0;}
    //info o każdym produkcie w oddzielnej linii
    public String toString(){
        String string = "";
        for(Product p : repository.findAll()) {
            string += p.toString() + "\n";
        }
        return string;
    }
}
